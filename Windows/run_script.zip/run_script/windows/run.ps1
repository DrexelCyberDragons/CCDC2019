./Sysmon64.exe -u
./Sysmon64.exe -i config.xml -n -accepteula