﻿#winlogbeat installer, as well as having 


function wmi_subscription_block($name, $query, $script){
        
        $Name = $name
        $Query = $query
        $EventNamespace = 'root/cimv2'
        $Class = 'ActiveScriptEventConsumer'

        # Define the signature - i.e. __EventFilter
        $EventFilterArgs = @{
            EventNamespace = $EventNamespace
            Name = $Name
            Query = $Query
            QueryLanguage = 'WQL'
        }

        $InstanceArgs = @{
            Namespace = 'root/subscription'
            Class = '__EventFilter'
            Arguments = $EventFilterArgs
        }
        $Filter = Set-WmiInstance @InstanceArgs

        # Define the Event Consumer - ACTION
        $EventConsumerArgs = @{
            Name = $Name
            ScriptingEngine = 'VBScript'
            ScriptText = 
            'Set objShell = CreateObject("Wscript.shell")
            objShell.run("' + $script + '")'
        }

        $InstanceArgs = @{
            Namespace = 'root/subscription'
            Class = $Class
            Arguments = $EventConsumerArgs
        }
        $Consumer = Set-WmiInstance @InstanceArgs

        $FilterConsumerBingingArgs = @{
            Filter = $Filter
            Consumer = $Consumer
        }

        $InstanceArgs = @{
            Namespace = 'root/subscription'
            Class = '__FilterToConsumerBinding'
            Arguments = $FilterConsumerBingingArgs
        }

        # Register the alert
        $Binding = Set-WmiInstance @InstanceArgs
}

function winlogbeat_install{

    # install winlogbeat
    cp -r "$work_dir\dm\wlb" "C:\Program Files\" 
    cd 'C:\Program Files\wlb'
    ./install-service-winlogbeat.ps1
    Start-sleep -s 10
    winlogbeat.exe setup --dashboards
    Start-service winlogbeat
    Write-Host -ForegroundColor Green "[+] Winlogbeat installed and configured! Check the below service listing to ensure it is started. `n"
    Get-Service winlogbeat
    Start-sleep -s 5

     wmi_subscription_block 'expIorer' 'Select * from __InstanceModificationEvent WITHIN 5 WHERE TargetInstance ISA "Win32_Service" AND TargetInstance.Name="winlogbeat" AND PreviousInstance.State="Running" AND TargetInstance.State="Stopped"' 'powershell -command start-service winlogbeat'
     wmi_subscription_block 'scvhost' 'Select * from __InstanceDeletionEvent WITHIN 5 WHERE TargetInstance ISA "Win32_Service" AND TargetInstance.Name="winlogbeat"' 'powershell C:\Windows\System32\wlb\catch.ps1'
     wmi_subscription_block 'lsasss' 'Select * from __InstanceDeletionEvent WITHIN 5 WHERE TargetInstance ISA "CIM_DataFile" AND TargetInstance.Drive = "C:" AND TargetInstance.Path = "\\Program Files\\winlogbeat\\"' 'powershell C:\Windows\System32\wlb\catch.ps1'
	    
}