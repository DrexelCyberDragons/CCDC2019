﻿<#
| Drexel Cyberdragons Blue Team Windows Domain Member script
| Last modified: 3/25/19
| Purpose: Lab hardening for a domain member
| Author: _abs0lute
#>

# Preliminary tasks, assess machine and run applicable tasks
# Assess Firewall, assess local accounts, enable remoting, pull gpo, grab applicable users

# Declare Variables
$ErrorActionPreference = 'SilentlyContinue'
$winrmversion = $PSVersionTable.WSManStackVersion.Major
$domainname = [string](Get-WmiObject Win32_ComputerSystem).Domain
$machinename = [string](Get-WmiObject Win32_ComputerSystem).Name
$dir_letter = ([string]$PWD)[0]
$path1 = "$dir_letter" +  ':\Windows\System32'
$full_path = [string](Get-ChildItem -Path $path1 -Recurse -ErrorAction SilentlyContinue -Include dm_script.ps1)
$work_dir = ([string]$full_path).replace("dm_script.ps1","")


# Assess admin group and change local admin password
function localAdminChange{
    Write-Host -ForegroundColor Cyan "`n-------Finding and Changing Local Admin User Password--------`n"
    try{
        Write-Host "All Admin Accounts"
        net localgroup Adminstrators
        Write-Host "Please enter a password for the local admin account"
        net user Administrator *
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]Admin account could not be queried/have their password changed, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

# Disables the guest account user, this won't work if the user is not named Guest
function localGuestChange{
    Write-Host -ForegroundColor Cyan "`n-------Finding and Changing Local Guest User Password--------`n"
    try{
        net localgroup Guests
        net user Guest /active:no
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]Guest account could not be disabled, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

# Pull GPO (This may fail, and you may have to pull manually)
function updateGPO{
    Write-Host -ForegroundColor Cyan "`n-------Updating GPO--------`n"
    try{
        Write-Host -ForeGroundColor Green '[+]Pulling and updating GPO'
        gpupdate /force
    }catch{
        $_.Exception.Message
        Write-Host -ForegroundColor Red "[!]GPO could not be pulled correctly, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

# install sysmon
function sysmon{
    Write-Host -ForegroundColor Cyan "`n-------Installing Sysmon!--------`n"
    try{
        cp -r "$work_dir\sint" ($dir_letter + ":\Windows\System32\")
        cd "$work_dir\sint"
        ./Sysmon.exe -i config.xml -n -accepteula -d windows
        Start-sleep -s 5
        Write-Host -ForegroundColor Green "[+]Sysmon installed!"
        # Remove-Item "$work_dir\config.xml"
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]Sysmon could not be installed, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

# enable firewall logging for different profiles
function firewall_log{
    Write-Host -ForegroundColor Cyan "`n-------Enabling the firewall on this profile and starting logging!--------`n"
    # https://support.microsoft.com/en-us/help/947709/how-to-use-the-netsh-advfirewall-firewall-context-instead-of-the-netsh
    try{
        # domain firewall logging
        Netsh advfirewall set currentprofile state on
        #Set-NetFirewallProfile -name domain,public,private -LogMaxSizeKilobytes 10240 -LogAllowed true -LogBlocked true
        netsh advfirewall set currentprofile logging filename %systemroot%\system32\LogFiles\Firewall\pfirewall.log
        netsh advfirewall set currentprofile logging maxfilesize 4096
        netsh advfirewall set currentprofile logging droppedconnections enable
	    netsh advfirewall firewall set rule group="Windows Management Instrumentation (WMI)" new enable=yes
        Write-Host -ForegroundColor Green "[+]Firewall enabled and logging setup!"
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]Firewall could not be configured properly, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

function wmi_subscription_block($name, $query, $script){
        
        $Name = $name
        $Query = $query
        $EventNamespace = 'root/cimv2'
        $Class = 'ActiveScriptEventConsumer'

        # Define the signature - i.e. __EventFilter
        $EventFilterArgs = @{
            EventNamespace = $EventNamespace
            Name = $Name
            Query = $Query
            QueryLanguage = 'WQL'
        }

        $InstanceArgs = @{
            Namespace = 'root/subscription'
            Class = '__EventFilter'
            Arguments = $EventFilterArgs
        }
        $Filter = Set-WmiInstance @InstanceArgs

        # Define the Event Consumer - ACTION
        $EventConsumerArgs = @{
            Name = $Name
            ScriptingEngine = 'VBScript'
            ScriptText = 
            'Set objShell = CreateObject("Wscript.shell")
            objShell.run("' + $script + '")'
        }

        $InstanceArgs = @{
            Namespace = 'root/subscription'
            Class = $Class
            Arguments = $EventConsumerArgs
        }
        $Consumer = Set-WmiInstance @InstanceArgs

        $FilterConsumerBingingArgs = @{
            Filter = $Filter
            Consumer = $Consumer
        }

        $InstanceArgs = @{
            Namespace = 'root/subscription'
            Class = '__FilterToConsumerBinding'
            Arguments = $FilterConsumerBingingArgs
        }

        # Register the alert
        $Binding = Set-WmiInstance @InstanceArgs
}

function wmi_subscriptions{
    Write-Host -ForegroundColor Cyan "`n-------Setting up WMI Event Subscriptions--------`n"
    try{
	    cp "$workdir\catch.ps1" C:\Windows\System32\
        #EXAMPLE: wmi_subscription_block 'name' 'query' 'powershell -command {cp c:\Users\a.txt c:\Windows\System32'
	    wmi_subscription_block 'tasskmgr' 'Select * from __InstanceModificationEvent WITHIN 5 WHERE TargetInstance ISA "Win32_Service" AND TargetInstance.Name="Sysmon" AND PreviousInstance.State="Running" AND TargetInstance.State="Stopped"' 'powershell -command start-service Sysmon'
        wmi_subscription_block 'winlogin' 'Select * from __InstanceModificationEvent WITHIN 5 WHERE TargetInstance ISA "Win32_Service" AND TargetInstance.Name="TermService" AND PreviousInstance.State="Running" AND TargetInstance.State="Stopped"' 'powershell -command start-service TermService'
        wmi_subscription_block 'winIogon' 'Select * from __InstanceModificationEvent WITHIN 5 WHERE TargetInstance ISA "Win32_Service" AND TargetInstance.Name="MpsSvc" AND PreviousInstance.State="Running" AND TargetInstance.State="Stopped"' 'powershell -command start-service MpsSvc'
        wmi_subscription_block 'scvvhost' 'Select * from __InstanceDeletionEvent WITHIN 5 WHERE TargetInstance ISA "Win32_Service" AND TargetInstance.Name="Sysmon"' 'powershell C:\Windows\System32\sint\run.ps1'
        Write-Host "Subscriptions Created!"
	    # Get-WmiObject -Namespace 'root/subscription' -Class '__EventFilter' | where-object {$_.Name -like "test*"} | Remove-WmiObject
	    # Get-WmiObject -Namespace 'root/subscription' -Class 'ActiveScriptEventConsumer' | where-object {$_.Name -like "StagingLocation*"} | Remove-WmiObject
	    # Get-WmiObject -Namespace 'root/subscription' -Class '__FilterToConsumerBinding' | where-object {$_.Filter -like "*StagingLocation*"} | Remove-WmiObject
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]WMI Event Subscriptions could not be created, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

# Disable NetBIOS on all adapters, not really necessary unless the domain is ancient
function netbios_disable{
    Write-Host -ForegroundColor Cyan "`n-------Querying NetBIOS setting--------`n"
    # Query for Netbios Registry Key and disable if necessary
    # 0 is enable NetBios from DHCP Server
    # 1 is enable NetBios over TCP/IP
    # 2 is disabled
    try{
        Write-host 'Netbios Registry Keys:'
        $key = "HKLM:SYSTEM\CurrentControlSet\services\NetBT\Parameters\Interfaces" 
        Get-ChildItem $key | foreach {$val = Get-ItemProperty -Path "$key\$($_.pschildname)" -Name NetbiosOptions; If ([int]$val.NetbiosOptions -eq 2){ Write-Host -ForegroundColor Green 'Adapter' $_.pschildname 'has NetBios Disabled!'}ElseIf([int]$val.NetbiosOptions -ne 2){Write-Host -ForegroundColor Red 'Adapter' + $_.pschildname + 'has NetBios Enabled!'}}
        Write-Host -ForegroundColor Yellow '[=]Would you like to disable Netbios across all interfaces?(If already disabled, ignore.  Be Careful, may break functionality for legacy systems)(y/n)'
        $yesorno = Read-Host
        If ($yesorno -eq 'y'){
               Get-ChildItem $key | foreach { Set-ItemProperty -Path "$key\$($_.pschildname)" -Name NetbiosOptions -Value 2 -Verbose}
               Write-Host -ForegroundColor Green '[+]Netbios Disabled'
        }
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]NetBIOS could not be queried/stopped, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

# Enable winrm and force event management through firewall
function winrmsetup{
    Write-Host -ForegroundColor Cyan "`n-------Setting up WinRM for remote management--------`n"
    try{
        # winrm / remote management steps
        Write-Host -ForegroundColor Yellow "[=]Checking WinRM Stack Version `n"
        Write-Host -ForegroundColor Yellow "[=]Seems to be version $winrmversion"
        netsh advfirewall firewall set rule group="Remote Event Log Management" new enable=yes
        Clear-item -Path WSMan:\localhost\Client\TrustedHosts -Force
        Enable-PSRemoting -Force
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]Something went wrong with WinRM setup, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

# Adding proper active directory groups locally.  Will hopefully not terminate if groups exist already
function local_add{
    Write-Host -ForegroundColor Cyan "`n-------Ensuring proper group membership--------`n"
    try{
        $host = hostname 
        $std_user = "User" + $host
        $adm_user = $std_user + "_adm"
        net localgroup Administrators $adm_user /add
        net localgroup 'Remote Desktop Users' $std_user /add 
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]Something went wrong with local groups, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

try {
    echo '' > c:/admin_test.txt
    rm c:/admin_test.txt
    Write-Host -ForegroundColor Green "$machinename"

    Start-Sleep -s 2
	systeminfo | findstr /B /C:"OS Name" /C:"OS Version"
    firewall_log
    Start-Sleep -s 2
    Write-Host "Enter the name of the domain controller you dropped the ad scripts on"
    $ad_host = Read-Host
    

    localAdminChange
    localGuestChange

    winrmsetup
    
    updateGPO
    Start-Sleep -s 2

    sysmon
    Start-Sleep -s 2

    netbios_disable
    Start-Sleep -s 2

    wmi_subscriptions
    Start-Sleep -s 2
    $dom = $domainname.Split(".")[0]
    $group = hostname 
    $group1 = $dom + "\Users" + $group
    $group_adm = $group1 + "_adm"
    net localgroup Administrators $group_adm /add
    net localgroup 'Remote Desktop Users' $group1 /add
    Write-Host "Opening hosts, look for anything suspicious"
    notepad C:\Windows\System32\drivers\etc\hosts
       
}catch{
 
    $ErrorMessage = $_.Exception.Message
    If ($ErrorMessage | Select-String -Pattern "Denied"){
        Write-Host -ForegroundColor Red $ErrorMessage
        Write-Host -ForegroundColor Red "`n`n[!]Access Denied, restarting as admin, enter credentials if/when prompted"
        $path = "& '$full_path" + "'"
        Start-Process powershell $path -verb runas -Wait; exit
        
    }
    Else{
        Write-Host -ForegroundColor Red "[!]Please assess error message for issue, exiting..."
        $ErrorMessage
        Start-Sleep -s 5
    }
    Write-Host "[!]Exiting!"
}