./Sysmon.exe -u
./Sysmon.exe -i config.xml -n -accepteula