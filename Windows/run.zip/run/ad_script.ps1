﻿<#
| Drexel Cyberdragons Blue Team Windows DC script
| Last modified: 3/25/19
| Purpose: Lab hardening for a domain controller, will assess available domain computers as well
| Author: _abs0lute
| Changelog: 
| - Updated admin context check
| - removed redundant sint copy
| - Added change at logon for user passwords, this was passwords are not static/known for long
#>


# Declare variables
$winrmversion = $PSVersionTable.WSManStackVersion.Major
$domainname = [string](Get-WmiObject Win32_ComputerSystem).Domain
$machinename = [string](Get-WmiObject Win32_ComputerSystem).Name
$usr_dc = ((Get-ADUser krbtgt).DistinguishedName.Split(","))
$dist_name = $usr_dc[$usr_dc.length - 3] + "," + $usr_dc[$usr_dc.length - 2] + "," + $usr_dc[$usr_dc.length - 1]
$ErrorActionPreference = 'SilentlyContinue'
$dir_letter = ([string]$PWD)[0]
$path1 = "$dir_letter" +  ':\Windows\System32'
$full_path = [string](Get-ChildItem -Path $path1 -Recurse -ErrorAction SilentlyContinue -Include ad_script.ps1)
$work_dir = ([string]$full_path).replace("ad_script.ps1","")

# Pull GPO (This may fail, and you may have to pull manually)
function updateGPO{
    Write-Host -ForegroundColor Cyan "`n-------Updating GPO--------`n"
    try{
        Write-Host -ForeGroundColor Green '[+]Pulling and updating GPO'
        gpupdate /force
    }catch{
        $_.Exception.Message
        Write-Host -ForegroundColor Red "[!]GPO could not be pulled correctly, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

# Run WMI commands against each machine in the domain and copies domain machine script to each C:\Windows\System32
function test_connectivity{
    Write-Host -ForegroundColor Cyan "`n-------Attempting connection via WMI--------`n"
    # If the RPC server is unavailable, will throw a non-terminating error so a bunch of errors is expected
    Write-Host -ForegroundColor Yellow "If you see a lot of red, it is to be expected!!!"
        try{
            $computers = @(Get-ADComputer -Filter *).DNSHostName
            foreach($comp in $computers){
                $output = (Invoke-WmiMethod -Class Win32_Process -Name Create -ArgumentList "cmd.exe" -ComputerName $host).ReturnValue
                if($output -eq 0){
                    Write-Host -ForegroundColor Green "[+]WMI successfully contacted on $comp, trying to invoke gpupdate via WMI"
                    Invoke-WmiMethod -Class Win32_Process -Name Create -ArgumentList "cmd.exe /c gpupdate /force" -ComputerName $host
                }else{
                    Write-Host -ForegroundColor Red "[-]WMI could not be contacted on $comp"
                }
                xcopy dm \\$host\c$\Windows\System32\dm /e /i /y /s
            }
        }catch{
            $_.Exception.Message
            Write-Host -ForegroundColor Red "[!]Something went wrong, please see above Error Message"
            Write-Host "Continue?"
            Read-Host
        }
}

# This script collection is meant to be as lightweight as possible, this will pull down all the packages that are to be used: Sysinternals tools, winlogbeat, Get-InjectedThread, GlassWire
# Necessary folders will be created
function pull_packages{
    Write-Host -ForegroundColor Cyan "`n-------Pulling all applicable packages--------`n"
    try{
        # Enable tls1.2
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        # Pull Sysinternals into sint directory
        Invoke-WebRequest -Uri https://live.sysinternals.com/Sysmon.exe -Outfile sint\Sysmon.exe
        Invoke-WebRequest -Uri https://live.sysinternals.com/procexp.exe -Outfile sint\procexp.exe
        Invoke-WebRequest -Uri https://live.sysinternals.com/Procmon.exe -Outfile sint\Procmon.exe
        Invoke-WebRequest -Uri https://live.sysinternals.com/autoruns.exe -Outfile sint\autoruns.exe
        Invoke-WebRequest -Uri https://live.sysinternals.com/Listdlls.exe -Outfile sint\Listdlls.exe
        # Pull GlassWire installer
        Invoke-WebRequest -Uri https://download.glasswire.com/GlassWireSetup.exe -Outfile sint\GlassWireSetup.exe
        # Pull Injected Thread GitHub Repo
        Invoke-WebRequest -Uri https://gist.github.com/jaredcatkinson/23905d34537ce4b5b1818c3e6405c1d2/raw/104f630cc1dda91d4cb81cf32ef0d67ccd3e0735/Get-InjectedThread.ps1 -Outfile Get-InjectedThread.ps1
        Invoke-WebRequest -Uri https://gist.github.com/jaredcatkinson/23905d34537ce4b5b1818c3e6405c1d2/raw/104f630cc1dda91d4cb81cf32ef0d67ccd3e0735/Stop-Thread.ps1 -Outfile Stop-Thread.ps1
        # Pull Malwarebytes installer
        Invoke-WebRequest -Uri https://downloads.malwarebytes.com/file/mb3 -Outfile mb3_setup.exe
        # Begin moving binaries to domain member folder and to System32
        copy mb3_setup.exe dm
        # Pull Winlogbeat installer
        Invoke-WebRequest -Uri https://artifacts.elastic.co/downloads/beats/winlogbeat/winlogbeat-6.6.1-windows-x86.zip -Outfile dm\wlb.zip
        Write-Host "Because Expand-Archive isnt the best thing to rely on, please expand the wlb archive manually"
        Write-Host "Drop your Winlogbeat config file here!  Winlogbeat is also a seperate install, please run .\winlog_install.ps1"
        # Expand-Archive is non-applicable to 95% of machines, so this must be done manually, opening explorer
        ii dm
        Write-Host "Press Enter To Continue"
        Read-Host
        # Pull sysinternals into dm directory and System32
        xcopy sint dm\sint /e /i /y /s
        xcopy sint C:\Windows\System32\sint /e /i /y /s
        # Move winlogbeat to Debug for added opsec
        xcopy dm\wlb C:\Windows\Debug\wlb /e /i /y /s
        

    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]Not all packages could be pulled"
        Write-Host "Continue?"
        Read-Host
    }
}

# Create domain users for each machine
function create_local_accts{
    Write-Host -ForegroundColor Cyan "`n-------Building Secure Accounts and Groups--------`n"
    Write-Host -ForegroundColor Yellow "If you see a lot of red, it is to be expected!!!"
    $usr_dc = ((Get-ADUser krbtgt).DistinguishedName.Split(","))
    # format the correct distinguished name 
    # This must be modified dependant number of DC segments in DN
    $dist_name = $usr_dc[$usr_dc.length - 3] + "," + $usr_dc[$usr_dc.length - 2] + "," + $usr_dc[$usr_dc.length - 1]
    $group = @()
    try{
        # Build out array of passwords
        $arr = @()
        foreach($line in Get-Content "$work_dir\a.txt"){
	        $arr += $line
        }
        $num = 0
        # Obtain list of ad computers, from the Computers OU
        $comps = @(Get-ADComputer -Filter * -SearchBase "CN=Computers,$dist_name").Name
        foreach($comp in $comps){
            $gname = "Users_$comp"
            $gname_adm = "Users_$comp" + "adm"
            $sam_name = "Users" + $comp
            $sam_name_adm = $sam_name + "_adm"
            $display_name = "Users $comp"
            $display_name_adm = "Users $comp adm"
            $desc = "Users for $comp"
            $user = $comp + "u"
            New-ADGroup -Name $gname -SamAccountName $sam_name -GroupCategory Security -GroupScope Global -DisplayName $display_name -Path "CN=Users,$dist_name" -Description $desc
            New-ADGroup -Name $gname_adm -SamAccountName $sam_name_adm -GroupCategory Security -GroupScope Global -DisplayName $display_name_adm -Path "CN=Users,$dist_name" -Description $desc
	        New-ADUser -Name $user -AccountPassword (ConvertTo-SecureString $arr[$num] -AsPlainText -Force) -Enabled $True -ChangePasswordAtLogon $True
            Write-host $user "   :   " $arr[$num]
            $num += 1
            $usern = $user + "adm"
            New-ADUser -Name $usern -AccountPassword (ConvertTo-SecureString $arr[$num] -AsPlainText -Force) -Enabled $True -ChangePasswordAtLogon $True
            Write-host $usern "   :   " $arr[$num]
            $num += 1 
            Add-AdGroupMember -Identity $sam_name -Members $user
            Add-AdGroupMember -Identity $sam_name_adm -Members $usern
            Add-AdGroupMember -Identity 'Remote Desktop Users' -Members $sam_name
            $arglist = "powershell.exe net localgroup 'Administrators' " + $domainname.Split(".")[0] + "\" + $sam_name + "_adm /add ; net localgroup 'Remote Desktop Users' " + $domainname.Split(".")[0] + "\" + $sam_name + " /add ; Enable-PSRemoting -Force"
            Invoke-WmiMethod -Class Win32_Process -Name Create -ArgumentList $arglist -ComputerName $comp  
        }
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]Not all local accounts could be created"
        Write-Host "Continue?"
        Read-Host
    }
}

# Enable winrm and force event management through firewall
function winrmsetup{
    Write-Host -ForegroundColor Cyan "`n-------Setting up WinRM for remote management--------`n"
    try{
        # winrm / remote management steps
        Write-Host -ForegroundColor Yellow "[=]Checking WinRM Stack Version `n"
        Write-Host -ForegroundColor Yellow "[=]Seems to be version $winrmversion"
        netsh advfirewall firewall set rule group="Remote Event Log Management" new enable=yes
        Clear-item -Path WSMan:\localhost\Client\TrustedHosts -Force
        Enable-PSRemoting -Force
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]Something went wrong with WinRM setup, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

# Disable NetBIOS on all adapters, not really necessary unless the domain is ancient
function netbios_disable{
    Write-Host -ForegroundColor Cyan "`n-------Querying NetBIOS setting--------`n"
    # Query for Netbios Registry Key and disable if necessary
    # 0 is enable NetBios from DHCP Server
    # 1 is enable NetBios over TCP/IP
    # 2 is disabled
    try{
        Write-host 'Netbios Registry Keys:'
        $key = "HKLM:SYSTEM\CurrentControlSet\services\NetBT\Parameters\Interfaces" 
        Get-ChildItem $key | foreach {$val = Get-ItemProperty -Path "$key\$($_.pschildname)" -Name NetbiosOptions; If ([int]$val.NetbiosOptions -eq 2){ Write-Host -ForegroundColor Green 'Adapter' $_.pschildname 'has NetBios Disabled!'}ElseIf([int]$val.NetbiosOptions -ne 2){Write-Host -ForegroundColor Red 'Adapter' + $_.pschildname + 'has NetBios Enabled!'}}
        Write-Host -ForegroundColor Yellow '[=]Would you like to disable Netbios across all interfaces?(If already disabled, ignore.  Be Careful, may break functionality for legacy systems)(y/n)'
        $yesorno = Read-Host
        If ($yesorno -eq 'y'){
               Get-ChildItem $key | foreach { Set-ItemProperty -Path "$key\$($_.pschildname)" -Name NetbiosOptions -Value 2 -Verbose}
               Write-Host -ForegroundColor Green '[+]Netbios Disabled'
        }
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]NetBIOS could not be queried/stopped, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}


# Install management roles on a machine you want to manage from
function management_roles{
    Write-Host -ForegroundColor Cyan "`n-------Installing Management Roles--------`n"
    # all roles necessary to manage an environment minus sql toolset
    try{
        Install-WindowsFeature Remote-Desktop-Services,GPMC,Web-Mgmt-Console,RSAT-Role-Tools,RSAT-AD-PowerShell,RSAT-DHCP,RSAT-DNS-Server -IncludeManagementTools
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]Roles could not be installed properly, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

# GPO creation and import, make sure backups are located in the run folder
function gpoimport{
    Write-Host -ForegroundColor Cyan "`n-------Importing GPO--------`n"
    # Import-Module GroupPolicy
    try{
        import-gpo -BackupGpoName 2012_Member_Security -TargetName 2012_Member_Security -path $work_dir -CreateIfNeeded | New-GPLink -Target "OU=Servers,$dist_name" -LinkEnabled Yes
        import-gpo -BackupGpoName Domain_Overall -TargetName Domain_Overall -path $work_dir -CreateIfNeeded | New-GPLink -Target "$dist_name" -LinkEnabled Yes
        import-gpo -BackupGpoName Domain_Member_Audit -TargetName Domain_Member_Audit -path $work_dir -CreateIfNeeded | New-GPLink -Target "OU=Servers,$dist_name" -LinkEnabled Yes
        import-gpo -BackupGpoName 2012_DC_Security -TargetName 2012_DC_Security -path $work_dir -CreateIfNeeded | New-GPLink -Target "OU=Domain Controllers,$dist_name" -LinkEnabled Yes
        import-gpo -BackupGpoName DC_Audit -TargetName DC_Audit -path $work_dir -CreateIfNeeded | New-GPLink -Target "OU=Domain Controllers,$dist_name" -LinkEnabled Yes
        #Remove whatever is applied manually, as these defaults may not exist and bad GPO's may exist already
        Remove-GPLink -Name "Default Domain Policy" -Target "$dist_name"
        Remove-GPLink -Name "Default Domain Controller Policy" -Target "OU=Domain Controllers,$dist_name"
        Write-Host -ForegroundColor Gray "[+]GPO Successfully Imported!"
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]GPO could not be imported, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

# Move all available AD machines to the newly created Servers OU
function AD_shimmy{
    Write-Host -ForegroundColor Cyan "`n-------Creating OU for Servers--------`n"
    try{
        # we can grab the distinguished name from something like this: (Get-ADUser username).DistinguishedName
        
        New-ADOrganizationalUnit -Name "Servers" -Path "$dist_name"
        # Display OU's
        Get-ADOrganizationalUnit -Filter 'Name -like "*"' | Format-Table Name, DistinguishedName -A
        Write-Host -ForegroundColor Green "[+]AD OU successfully created!"
        $comps = @(Get-ADComputer -Filter *)
        foreach($comp in $comps){
            if(-Not($comp.DistinguishedName -match "Domain Controllers")){
                Move-ADObject -Identity $comp.DistinguishedName -TargetPath "OU=Servers,$dist_name"
            }
        }
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]OU could not be created, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

# install sysmon
function sysmon{
    Write-Host -ForegroundColor Cyan "`n-------Installing Sysmon!--------`n"
    try{
        cd "$work_dir\sint"
        ./Sysmon.exe -i config.xml -n -accepteula -d windows
        Start-sleep -s 5
        Write-Host -ForegroundColor Green "[+]Sysmon installed!"
        # Remove-Item "$work_dir\config.xml"
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]Sysmon could not be installed, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

# enable firewall logging for different profiles
function firewall_log{
    Write-Host -ForegroundColor Cyan "`n-------Enabling the firewall on this profile and starting logging!--------`n"
    # https://support.microsoft.com/en-us/help/947709/how-to-use-the-netsh-advfirewall-firewall-context-instead-of-the-netsh
    try{
        # domain firewall logging
        Netsh advfirewall set currentprofile state on
        #Set-NetFirewallProfile -name domain,public,private -LogMaxSizeKilobytes 10240 -LogAllowed true -LogBlocked true
        netsh advfirewall set currentprofile logging filename %systemroot%\system32\LogFiles\Firewall\pfirewall.log
        netsh advfirewall set currentprofile logging maxfilesize 4096
        netsh advfirewall set currentprofile logging droppedconnections enable
	    netsh advfirewall firewall set rule group="Windows Management Instrumentation (WMI)" new enable=yes
        Write-Host -ForegroundColor Green "[+]Firewall enabled and logging setup!"
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]Firewall could not be configured properly, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

# Create a bunch of new DA users for IR to use
function priv_create{
    Write-Host -ForegroundColor Cyan "`n-------Creating privileged Users User7 and User10--------`n"
    try{
        Write-Host "Enter a password for user: User7 `n"
        $user1_pass = Read-Host -AsSecureString
        New-ADUser -Name "User7" -AccountPassword $user1_pass -Enabled $True
        Add-ADGroupMember -Identity "Enterprise Admins" -Members User7
        Write-Host "Enter a password for user: User10 `n"
        $user10_pass = Read-Host -AsSecureString
        New-ADUser -Name "User10" -AccountPassword $user10_pass -Enabled $True
        Add-ADGroupMember -Identity "Domain Admins" -Members User10

        Write-Host -ForegroundColor Green "[+]User7 Added to EA group"
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]Not all accounts could be created, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

# Enumerate all available admin users
function priv_assess{
    Write-Host -ForegroundColor Cyan "`n-------Assessing Admin Accounts for the Domain!--------`n"
    try{
        #Iterate through Admin group recursively
        $accts = @(Get-ADGroupMember -Identity "Administrators" -Recursive).distinguishedName
        Write-Host -ForegroundColor Green "[+]All of the Privileged Users: $accts.length"
        $accts
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]Something went wrong, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

# Function block to set wmi subscriptions
function wmi_subscription_block($name, $query, $script){
        
        $Name = $name
        $Query = $query
        $EventNamespace = 'root/cimv2'
        $Class = 'ActiveScriptEventConsumer'

        # Define the signature - i.e. __EventFilter
        $EventFilterArgs = @{
            EventNamespace = $EventNamespace
            Name = $Name
            Query = $Query
            QueryLanguage = 'WQL'
        }

        $InstanceArgs = @{
            Namespace = 'root/subscription'
            Class = '__EventFilter'
            Arguments = $EventFilterArgs
        }
        $Filter = Set-WmiInstance @InstanceArgs

        # Define the Event Consumer - ACTION
        $EventConsumerArgs = @{
            Name = $Name
            ScriptingEngine = 'VBScript'
            ScriptText = 
            'Set objShell = CreateObject("Wscript.shell")
            objShell.run("' + $script + '")'
        }

        $InstanceArgs = @{
            Namespace = 'root/subscription'
            Class = $Class
            Arguments = $EventConsumerArgs
        }
        $Consumer = Set-WmiInstance @InstanceArgs

        $FilterConsumerBingingArgs = @{
            Filter = $Filter
            Consumer = $Consumer
        }

        $InstanceArgs = @{
            Namespace = 'root/subscription'
            Class = '__FilterToConsumerBinding'
            Arguments = $FilterConsumerBingingArgs
        }

        # Register the alert
        $Binding = Set-WmiInstance @InstanceArgs
}

# Set our own persistent mechanisms
# In theory this will combat simple stopping of sysmon, rdp, firewall.  Sysmon in theory will be able to combat deletion of its service entirely
function wmi_subscriptions{
    Write-Host -ForegroundColor Cyan "`n-------Setting up WMI Event Subscriptions--------`n"
    try{
	    cp "$workdir\catch.ps1" C:\Windows\System32\
        #EXAMPLE: wmi_subscription_block 'name' 'query' 'powershell -command {cp c:\Users\a.txt c:\Windows\System32'
	    wmi_subscription_block 'tasskmgr' 'Select * from __InstanceModificationEvent WITHIN 5 WHERE TargetInstance ISA "Win32_Service" AND TargetInstance.Name="Sysmon" AND PreviousInstance.State="Running" AND TargetInstance.State="Stopped"' 'powershell -command start-service Sysmon'
        wmi_subscription_block 'winlogin' 'Select * from __InstanceModificationEvent WITHIN 5 WHERE TargetInstance ISA "Win32_Service" AND TargetInstance.Name="TermService" AND PreviousInstance.State="Running" AND TargetInstance.State="Stopped"' 'powershell -command start-service TermService'
        wmi_subscription_block 'winIogon' 'Select * from __InstanceModificationEvent WITHIN 5 WHERE TargetInstance ISA "Win32_Service" AND TargetInstance.Name="MpsSvc" AND PreviousInstance.State="Running" AND TargetInstance.State="Stopped"' 'powershell -command start-service MpsSvc'
        wmi_subscription_block 'scvvhost' 'Select * from __InstanceDeletionEvent WITHIN 5 WHERE TargetInstance ISA "Win32_Service" AND TargetInstance.Name="Sysmon"' 'powershell C:\Windows\System32\sint\run.ps1'
        Write-Host "Subscriptions Created!"
	    # Get-WmiObject -Namespace 'root/subscription' -Class '__EventFilter' | where-object {$_.Name -like "test*"} | Remove-WmiObject
	    # Get-WmiObject -Namespace 'root/subscription' -Class 'ActiveScriptEventConsumer' | where-object {$_.Name -like "StagingLocation*"} | Remove-WmiObject
	    # Get-WmiObject -Namespace 'root/subscription' -Class '__FilterToConsumerBinding' | where-object {$_.Filter -like "*StagingLocation*"} | Remove-WmiObject
    }catch{
        $_.Exception
        Write-Host -ForegroundColor Red "[!]WMI Event Subscriptions could not be created, please see above Error Message"
        Write-Host "Continue?"
        Read-Host
    }
}

try {
    # Updated admin check
    $currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    if ($currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) -eq $True){

        #Begin to ask if DC, DM, or Management machine
        Write-Host -ForegroundColor Green "$machinename"

        Start-Sleep -s 2
	    systeminfo | findstr /B /C:"OS Name" /C:"OS Version"
        firewall_log
        Start-Sleep -s 2

        priv_assess
        Start-Sleep -s 2

        priv_create
        Start-Sleep -s 2

        pull_packages

        test_connectivity

        create_local_accts
        Start-Sleep -s 2

        # Delete initial password sheet
        rm a.txt

        ad_shimmy
        Start-Sleep -s 2

        gpoimport
        Start-Sleep -s 2
    
        updateGPO
        Start-Sleep -s 2

        sysmon
        Start-Sleep -s 2

        netbios_disable
        Start-Sleep -s 2

        wmi_subscriptions
        Start-Sleep -s 2

        Write-Host "Opening hosts, look for anything suspicious"
        notepad C:\Windows\System32\drivers\etc\hosts

    }else{
        Write-Host -ForegroundColor Red "`n`n[!]Access Denied, restarting as admin, enter credentials if/when prompted"
        $path = "& '$full_path" + "'"
        Start-Process powershell $path -verb runas -Wait; exit
    }
       
}catch{
    $ErrorMessage = $_.Exception.Message
    Write-Host -ForegroundColor Red "[!]Please assess error message for issue, exiting..."
    $ErrorMessage
    Start-Sleep -s 5
    Write-Host "[!]Exiting!"
}