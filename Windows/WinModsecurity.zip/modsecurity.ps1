﻿# Opening README and web.config
$dir_letter = ([string]$PWD)[0]
$webpath = "$dir_letter" +  ':\inetpub'
$webfull_path = [string](Get-ChildItem -Path $webpath -Recurse -ErrorAction SilentlyContinue -Include web.config)
#$webwork_path = ([string]$webfull_path).replace("web.config","")

$modpath = "$dir_letter" + ':\Program Files\ModSecurity IIS\README'

Start-Process Notepad $webfull_path
Start-Process Notepad $modpath

# Changing configuration from DectionOnly to On
$file = 'C:\Program Files\ModSecurity IIS\modsecurity.conf'
$regex = '^SecRuleEngine.*'
(Get-Content -Path $file ) -replace $regex, 'SecRuleEngine On' | Set-Content $file
Start-Process Notepad $file

# restarting iis
iisreset /restart

# disabling some rules ID: 920350
Add-Content "C:\Program Files\ModSecurity IIS\owasp_crs\rules\RESPONSE-999-EXCLUSION-RULES-AFTER-CRS.conf" "SecRuleRemoveByID 920350"
Start-Process Notepad "C:\Program Files\ModSecurity IIS\owasp_crs\rules\RESPONSE-999-EXCLUSION-RULES-AFTER-CRS.conf"







